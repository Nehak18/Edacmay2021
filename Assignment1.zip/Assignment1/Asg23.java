class Asg23
{
public static void main(String args[])
{
    long num = 01011011;	//binary 127
    int dec_value = 0;	//decimal

    // Initializing base value to 1, i.e 2^0

    int base = 1;
 
    long temp = num;

    while (temp!=0) 
	{
        int last_digit = (int)temp % 10;
        temp = temp / 10;
 
        dec_value = dec_value + last_digit * base;

        base = base * 2;
	}
  System.out.println(dec_value);
  dec_value=91;
  int a=0;
  int hexadec[]=new int[1000];
  while(dec_value!=0)
  {
	  hexadec[a]=dec_value%16; 
	  
	  dec_value=dec_value/16;
	  a++;
	  
  }
  for(int i=a-1;i>-1;i--)
	{
		if(hexadec[i]>9)
			System.out.print((char)(hexadec[i]+55));
		else
			System.out.print(hexadec[i]);
	}
 
    
}
}