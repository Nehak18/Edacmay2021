import java.util.*;
import java.lang.*;
class Asg7
{
  public static void main(String args[])
  {
   //  Scanner sc=new Scanner(System.in);
   // System.out.println("Enter a number");
   int i=8,x=0,y;
	 if(x<=10)
	 {
	 x=x+1;
	
	 System.out.println("Table of 8 is"+y);
	 y=x*i;
	 }
	 else
	 System.out.println("enod of table");
  
  }

}