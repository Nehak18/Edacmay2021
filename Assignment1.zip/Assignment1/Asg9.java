class Asg9
{
  public static void main(String args[])
  {
     double a=25.5,b=3.5,c=40.5,d=4.5;
	double num=((a*b-b*b)/(c-d));
	 System.out.println(num);
  
  }


}