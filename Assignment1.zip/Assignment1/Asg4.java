import java.util.*;
import java.lang.*;
public class Asg4
{
  public static void main(String args[])
  {
   int n1=-5,n2=8,n3=6,a;
   a=n1+n2*n3;
   System.out.println("a ="+a);
   
   int n4=55,n5=9,n6=9,b;
   b=(n4+n5)%n6;
   System.out.println("b ="+b);
   
   int m1=20,m2=-3,m3=5,m4=8,c;
   c=m1+m2*m3/m4;
   System.out.println("c ="+c);
  
   int l1=5,l2=15,l3=3,l4=2,l5=8,l6=3,d;
   d=l1+l2/l3*l4-l5%l6;
   System.out.println("d ="+d);
  }


}