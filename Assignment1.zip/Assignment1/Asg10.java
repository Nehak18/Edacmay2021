class Asg10
{
   public static void main(String args[])
   {
     double a=4.0,b=1,c=1.0,d=3,e=5,f=7,g=9,h=11;
	 double num=a*(b-(c/d)+(c/e)-(c/f)+(c/g)-(c/h));
	 System.out.println(num);
   
   }


}
