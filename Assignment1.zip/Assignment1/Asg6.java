import java.util.*;
import java.lang.*;
public class Asg6
{
   public static void main(String args[])
   {
      Scanner sc=new Scanner(System.in);
	  System.out.println("Enter two numbers");
	  int i=sc.nextInt();
	  int j=sc.nextInt();
	  int k = i+j;
	  int l = i-j;
	  int n = i*j;
	  int m = i/j;
	  int p = i%j;
	  System.out.println(i+ "+" +j+ "=" +k); 
	  System.out.println(i+ "-" +j+ "=" +l);
	  System.out.println(i+ "*" +j+ "=" +n);
	  System.out.println(i+ "/" +j+ "=" +m);
	  System.out.println(i+ "%" +j+ "=" +p);
	  
	 
   
   }

}