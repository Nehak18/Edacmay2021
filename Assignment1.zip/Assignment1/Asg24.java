class Asg24
{
  public static void main(String args[])
{
   int num=1010;
   int dec_value=0;
   int base=1;
   int temp=num;
   while(temp>0)
   {
     int last_digit=temp%8;
     temp=temp/8;
     dec_value=dec_value+last_digit*base;
     base=base*2;


   }
 System.out.println(dec_value);


}
}