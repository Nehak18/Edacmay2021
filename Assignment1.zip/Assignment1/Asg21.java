class Asg21
{
public static void main(String args[])
{
    int num = 123;	//binary
    int octal = 0;	//decimal

    // Initializing base value to 1, i.e 10^0

    int base = 1;
 
    int temp = num;

    while (temp!=0) 
{
        int last_digit =temp % 8;  //  123%8=3 ,15%8=7 ,1%8=1
        temp = temp / 8;     		//123/8=15 ,15/8=1 ,1/8=0
 
        octal = octal + last_digit * base;//0+3*1=3 ,3+7*10=73 ,73+1*100=173

        base = base * 10; //1*10=10,10*10=100,
  }
  System.out.println(octal);
    
}
}
 
