import java.util.*;
import java.lang.*;
class Asg2
{
  public static void main(String args[])
  {
   
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter two numbers");
	int i=sc.nextInt();
	int j=sc.nextInt();
    int k=i+j;
	 
	System.out.println("First number"+i);
	System.out.println("Second number"+j);
	System.out.println("Addition of two numbers"+k);
  }

}