class Asg18
{
public static void main(String args[])
{
    int num =10001111;   
	int num2=111;	//binary
    int dec_value = 0;
	int dec2=0;	//decimal

    // Initializing base value to 1, i.e 2^0

    int base1=1;
	int base2=1;
 
    int temp = num;
	int temp2=num2;

    while (temp>0) 
	{
        int last_digit= temp % 10;
        temp = temp / 10;
 
        dec_value = dec_value + last_digit * base1;

        base1 = base1 * 2;
	}
  System.out.println(dec_value);
  int a=0;
  int hexadec[]=new int[1000];
  while(dec_value!=0)
  {
	  hexadec[a]=dec_value%16; 
	  
	  dec_value=dec_value/16;
	  a++;
	  
  }
  for(int i=a-1;i>=0;i--)
	{
		if(hexadec[i]>9)
			System.out.print((char)(hexadec[i]+55));
		else
			System.out.print(hexadec[i]);
	}
 
}
}
 
