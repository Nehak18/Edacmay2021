import java.util.*;
import java.lang.*;
class Asg13
{
 public static void main(String args[])
	{
  float a,p;
  Scanner sc=new Scanner(System.in);
  System.out.println("enter the length and width");
  float l=sc.nextFloat();
  float w=sc.nextFloat();
  a=l*w;
  p=2*l+2*w;
  System.out.println((String.format("%10f",a)));
  System.out.println((String.format("%10f",p)));
	}
}