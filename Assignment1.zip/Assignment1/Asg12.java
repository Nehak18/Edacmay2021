import java.util.*;
import java.lang.*;
class Asg12
{
  public static void main(String args[])
  {
  int sum,avg,n=3;
   Scanner sc=new Scanner(System.in);
   System.out.println("enter three numbers");
   int a=sc.nextInt();
   int b=sc.nextInt();
   int c=sc.nextInt();
   sum=a+b+c;
   avg=sum/3;
   System.out.println("average of number"+avg);
  }

}