class Asg19
{
   public static void main(String args[])
   {
      int binary[]=new int[20];
      int n=10;
      int index=0;
      while(n>0)
      {
          binary[index++]=n%2;
          n=n/2;
       }

   for(int i=index-1;i>=0;i--)
       {
           System.out.println(binary[i]);
       }

   }




}