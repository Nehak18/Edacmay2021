class Asg22
{
public static void main(String args[])
{
    long num = 1111;	//binary
    int dec_value = 0;	//decimal

    // Initializing base value to 1, i.e 2^0

    int base = 1;
 
    long temp = num;

    while (temp!=0) 
{
        long last_digit =temp % 10;
        temp = temp / 10;
 
        dec_value = dec_value + (int)last_digit * base;

        base = base * 2;
  }
  System.out.println(dec_value);
    
}
}
 
