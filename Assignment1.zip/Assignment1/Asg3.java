public class Asg3
{
  public static void main(String args[])
  {
    String s1=args[0];
	String s2=args[1];
	
	int i=Integer.parseInt(s1);
	int j=Integer.parseInt(s2);
	int k=i/j;
  
  System.out.println("First number"+i);
  System.out.println("Second number"+j);
  System.out.println("Answer is"+k);
  
  }

}