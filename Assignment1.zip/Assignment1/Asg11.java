import java.util.*;
import java.lang.*;
class Asg11
{
  public static void main(String args[])
  {
    double a,p;
    Scanner sc=new Scanner(System.in);
	System.out.println("enter a radius");
	double r=sc.nextDouble();
	a=3.14*r*r;
	p=2*3.14*r;
	System.out.println((String.format("%.20f",a)));
	System.out.println((String.format("%.20f",p)));
  
  }

}