class Asg15
{
 public static void main(String args[])
 {
    int a=10,b=20;
	System.out.println("value of a is"+a);
	System.out.println("value of b is"+b);
    a=a*b;
    b=a/b;
    a=a/b;
	System.out.println("value of a is"+a);
	System.out.println("value of b is"+b);
 }




}
 /*a=a+b;
 b=a-b;
 a=a-b;

a=a*b;
b=a/b;
a=a/b;

a=a^b;
b=a^b;
a=a^b;

*/