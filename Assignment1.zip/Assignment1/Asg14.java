class Asg14
{
  public static void main(String args[])
  {
	  
     for(int i=1;i<=9;i++)
	 { 
     
	    for(int j=1;j<=5;j++)
		{
	      if(i%2==0)
		  {
		   System.out.print(" "+"*");
		  }
	    }
		
		
		for(int k=1;k<=6;k++)
		{
			if(i%2!=0)
			System.out.print("*"+" ");
		    
			
		}
		  for(int l=6;l<=16;l++)
		{
			
			System.out.print("==");
		}
		
		
	 System.out.println();
	 }
     for(int m=1;m<=6;m++)
	 {
		
	 
	 for(int p=10;p<=26;p++)
	 {
		 System.out.print("==");
	 }
    System.out.println();
  }
  }

}